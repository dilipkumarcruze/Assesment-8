package com.main;
import java.util.List;
import javax.sql.DataSource;


public interface WholesalerDao {
	
	public List<Wholesaler> listWholesaler();
int createWholesaler(Wholesaler wholesaler);
	
	void createWholesalerTable();
}

 

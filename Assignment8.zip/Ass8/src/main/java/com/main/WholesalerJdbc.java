package com.main;
import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

public class WholesalerJdbc implements WholesalerDao {

	DataSource datasource;
	JdbcTemplate jdbcTemplate;

	@Autowired
	WholesalerJdbc(DataSource datasource){
		this.jdbcTemplate = new JdbcTemplate(datasource);
	}

	public List<Wholesaler> listWholesaler() {
		List<Wholesaler> wholesalerList = jdbcTemplate.query("select * from WHOLESALER", new WholesalerMapper());

		return wholesalerList;
	}

	public void createWholesalerTable() {
		jdbcTemplate.execute("CREATE TABLE WHOLESALER(name varchar(40), age int,annualIncome float)");		
	}

	@Transactional
	public int createWholesaler(Wholesaler wholesaler) {
		int count = jdbcTemplate.update("insert into WHOLESALER(name,age,annualIncome) values(?,?,? )",
				wholesaler.getName(), wholesaler.getAge(),wholesaler.getAnnualIncome());

		return count;
	}
	



}




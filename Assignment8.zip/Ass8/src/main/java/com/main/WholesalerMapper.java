package com.main;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class WholesalerMapper implements RowMapper<Wholesaler> {
	public Wholesaler mapRow(ResultSet resultSet, int i) throws SQLException {

		Wholesaler wholesaler = new Wholesaler();
		
		wholesaler.setName(resultSet.getString("name"));
		wholesaler.setAge(resultSet.getInt("age"));
		wholesaler.setAnnualIncome(resultSet.getFloat("annualIncome"));

		
		return wholesaler;
	}
}
 

	


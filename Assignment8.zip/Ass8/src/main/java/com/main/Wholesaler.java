
package com.main;
public class Wholesaler {
	//name, age, annualIncome
	private static String name;
	private static int age;
	private static double annualIncome;
	
	public Wholesaler() {
		this(name, age, annualIncome);
	}
	public Wholesaler(String name,int age,double annualIncome) {
		this.name=name;
		this.age=age;
		this.annualIncome=Wholesaler.annualIncome;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}
	
}

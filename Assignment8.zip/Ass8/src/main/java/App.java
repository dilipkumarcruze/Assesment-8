import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.main.Wholesaler;


public class App {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringJdbcConfig.class);		
		Wholesaler w1 = context.getBean("abc", Wholesaler.class);
		System.out.format("\n Farmer name is %s and age %s and annualIncome %s", w1.getName(), w1.getAge(),w1.getAnnualIncome());

		Wholesaler w2 = context.getBean("abc2", Wholesaler.class);
		System.out.format("\n Farmer name is %s and age %s and annualIncome %s", w2.getName(), w2.getAge(),w2.getAnnualIncome());

		Wholesaler w3 = context.getBean("Sujata33Wholesaler", Wholesaler.class);
		System.out.format("\n Farmer name is %s and age %s and annualIncome %s", w3.getName(), w3.getAge(),w3.getAnnualIncome());

		Wholesaler w4 = context.getBean( Wholesaler.class); // we will get the primary bean if one exists
		System.out.format("\n Farmer name is %s and age  %s and ", w4.getName(), w4.getAge(),w4.getAnnualIncome());
		
		
	
	}

}

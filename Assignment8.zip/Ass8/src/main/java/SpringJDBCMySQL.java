import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.main.Wholesaler;
import com.main.WholesalerDao;
import com.main.WholesalerJdbc;



public class SpringJDBCMySQL {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringJdbcConfig.class);

		WholesalerDao wholesalerDAO = context.getBean(WholesalerJdbc.class);

	

		// verify we get two rows from the table
		List<Wholesaler> WholesalerList = null;
		try {
			WholesalerList = WholesalerDao.listWholesaler();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.format("\n List in the Wholesaler Table");
		System.out.format("\n -----------------------------------");
		for (Wholesaler w : WholesalerList) {
			System.out.format("\n %s, %s, %s", w.getName(), w.getAge(), w.getAnnualIncome());
		};
		
		

	}
}

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.amzn.beans.Farmer;
import com.main.Wholesaler;



@ComponentScan("com.main")
@Configuration
@EnableAspectJAutoProxy
public class SpringJdbcConfig {
	@Bean
	public Wholesaler abc() {		
		return new Wholesaler("quresh", 64,75690.7);
	}
	
	@Bean
	public Wholesaler abc2() {
		return new Wholesaler("Keerti", 64,75000.7);
	}	
	
	@Bean
	public Wholesaler abc3() {
		return new Wholesaler("Sujata", 33,74000.9);
	}
	
	@Primary // Only one bean per class type(Farmer) is allowed 
	@Bean("Ali93Wholesaler")
	public Wholesaler farmer4() {
		return new Wholesaler("Ali", 93,96000.4);
	}
	
	
    @Bean public DataSource mysqlDataSource()
    {
        DriverManagerDataSource dataSource
            = new DriverManagerDataSource();
        dataSource.setDriverClassName(
            "com.mysql.jdbc.Driver");
        dataSource.setUrl(
            "jdbc:mysql://127.0.0.1:3306/amzn");
        dataSource.setUsername("root");
        dataSource.setPassword("Sandy100@");
 
        return dataSource;
    }
}
